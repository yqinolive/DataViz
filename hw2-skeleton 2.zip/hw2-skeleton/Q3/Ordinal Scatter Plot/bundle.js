(function (d3) {
  'use strict';


    var colorLegend = (selection, props) => {
    var {                      
      colorScale,                
      circleRadius,
      spacing,                   
      textOffset,
      backgroundRectWidth,
    } = props;                   
    
    var backgroundRect = selection.selectAll('rect')
      .data([null]);             
    var n = colorScale.domain().length; 
    backgroundRect.enter().append('rect')
      .merge(backgroundRect)
        .attr('x', -circleRadius * 2)   
        .attr('y', -circleRadius * 2)   
        .attr('rx', circleRadius * 2)   
        .attr('width', backgroundRectWidth)
        .attr('height', spacing * n + circleRadius * 2) 
        .attr('fill', 'white');
        //.attr('opacity', 0.8);
    

    var groups = selection.selectAll('.tick')
      .data(colorScale.domain());
    var groupsEnter = groups
      .enter().append('g');
    groupsEnter
      .merge(groups)
        .attr('transform', (d, i) =>    
          `translate(0, ${i * spacing})`  
        );

    groups.exit().remove();
    
    groupsEnter.append('circle')
      .merge(groups.select('circle')) 
        .attr('r', circleRadius)
        .attr('stroke', colorScale)
        .attr("stroke-width",2);      
    
    groupsEnter.append('text')
      .merge(groups.select('text'))   
        .text(d => d)
        .attr('dy', '0.32em')
        .attr('x', textOffset);
  };



  // const data = () =>
  //   d3.csv('https://raw.githubusercontent.com/yqinolive/DataViz/master/movies.csv')
  //     .then(data => {

  //       data.forEach(d => {
  //       d.Rating = +d.Rating 
  //       d.WinsNoms = +d.WinsNoms
  //       d.year = +d.year
  //       d.Budget =+ d.Budget;
  //         //console.log(d.median);
  //       });

  //       return data;
  //     });



  // var svg = d3.select('svg');

  // var width = +svg.attr('width');
  // var height = +svg.attr('height');

  var colorScale = d3.scaleOrdinal()
    .domain(['bad rating','good rating'])
    .range(['red','blue']);

d3.csv("https://raw.githubusercontent.com/yqinolive/DataViz/master/movies.csv")
    .then(function(data) {
    data.forEach(d => {
        d.Rating = +d.Rating 
        d.WinsNoms = +d.WinsNoms
        d.year = +d.year
        d.Budget =+ d.Budget;
        });

    // var svg = d3.select('svg');

    // var width = +svg.attr('width');
    // var height = +svg.attr('height');

    var xValue = d => d.Rating;
    var xAxisLabel = 'Rating';
    
    var yValue = d => d.WinsNoms;
    var yAxisLabel = 'Wins+Noms';
    var circleRadius = 5;
    
    var title = 'Wins+Nominations (square-root-scaled) vs. Rating';
    var margin = { top: 50, right: 120, bottom: 77, left: 120 };
    var innerWidth = width - margin.left - margin.right;
    var innerHeight = height - margin.top - margin.bottom;
    
    var xScale = d3.scaleLinear()
      .domain(d3.extent(data, xValue))
      .range([0, innerWidth])
      .nice();
    
    var yScale = d3.scaleLinear()
      .domain(d3.extent(data, yValue))
      .range([innerHeight, 0])
    	.nice();  

    var g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);
    
    var xAxisTickFormat = number =>
      d3.format('.2s')(number)
        .replace('G', 'B');
    
    var xAxis = d3.axisBottom(xScale)
      .tickFormat(xAxisTickFormat)
      .tickSize(-innerHeight)
    	.tickPadding(20);
    
    var yAxis = d3.axisLeft(yScale)
      .tickSize(-innerWidth);
    
    var yAxisG = g.append('g').call(yAxis);
    yAxisG.selectAll('.domain').remove();
    
    var xAxisG = g.append('g').call(xAxis)
      .attr('transform', `translate(0,${innerHeight})`);
    
    yAxisG.append('text')
        .attr('class', 'axis-label')
        .attr('y', -70)
        .attr('x', -innerHeight/2)
    		.attr('transform', `rotate(-90)`)
    		.attr('text-anchor', 'middle')
        .attr('fill', 'black')
        .text(yAxisLabel);
    
    xAxisG.select('.domain').remove();
    
    xAxisG.append('text')
        .attr('class', 'axis-label')
        .attr('y', 65)
        .attr('x', innerWidth / 2)
        .attr('fill', 'black')
        .text(xAxisLabel);

    var svg = d3.select('svg');

    var width = +svg.attr('width');
    var height = +svg.attr('height');
    
    g.selectAll('circle').data(data)
      .enter().append('circle')
        .attr('cy', d => yScale(yValue(d)))
        .attr('cx', d => xScale(xValue(d)))
        .attr('r', circleRadius)
        .attr('stroke', d => colorScale(d.IsGoodRating))
        .attr("fill", "None")
        /*
        .attr("stroke", function(d) {
          if (d.IsGoodRating == 1 ) {
                  return "blue"
            } else {
                  return "red"
            }
         })*/
        .attr("stroke-width",2);


    var colorLegendG = svg.append('g')
        .attr('transform', `translate(860,70)`);
    
    colorLegendG.call(colorLegend, {
      colorScale,
      circleRadius: 8,
      spacing: 20,
      textOffset: 12,
      backgroundRectWidth: 120
    });


    g.append('text')
        .attr('class', 'title')
        .attr('y', -10)
        .text(title);
  //};

///////////////////

    var svg = d3.select('svg');

    var width = +svg.attr('width');
    var height = +svg.attr('height');

    var xValue = d => d.Rating;
    var xAxisLabel = 'Rating';
    
    var yValue2 = d => d.Budget;
    var yAxisLabel = 'Budget';
    var circleRadius = 5;
    
    var title2 = 'Budget vs. Rating';
    var margin = { top: 50, right: 120, bottom: 77, left: 120 };
    var innerWidth = width - margin.left - margin.right;
    var innerHeight = height - margin.top - margin.bottom;
    
    var xScale = d3.scaleLinear()
      .domain(d3.extent(data, xValue))
      .range([0, innerWidth])
      .nice();
    
    var yScale = d3.scaleLinear()
      .domain(d3.extent(data, yValue2))
      .range([innerHeight, 0])
      .nice();  

    var g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);
    
    var xAxisTickFormat = number =>
      d3.format('.2s')(number)
        .replace('G', 'B');
    
    var xAxis = d3.axisBottom(xScale)
      .tickFormat(xAxisTickFormat)
      .tickSize(-innerHeight)
      .tickPadding(20);
    
    var yAxis = d3.axisLeft(yScale)
      .tickSize(-innerWidth);
    
    var yAxisG = g.append('g').call(yAxis);
    yAxisG.selectAll('.domain').remove();
    
    var xAxisG = g.append('g').call(xAxis)
      .attr('transform', `translate(0,${innerHeight})`);
    
    yAxisG.append('text')
        .attr('class', 'axis-label')
        .attr('y', -70)
        .attr('x', -innerHeight/2)
        .attr('transform', `rotate(-90)`)
        .attr('text-anchor', 'middle')
        .attr('fill', 'black')
        .text(yAxisLabel);
    
    xAxisG.select('.domain').remove();
    
    xAxisG.append('text')
        .attr('class', 'axis-label')
        .attr('y', 65)
        .attr('x', innerWidth / 2)
        .attr('fill', 'black')
        .text(xAxisLabel);

    
    g.selectAll('circle').data(data)
      .enter().append('circle')
        .attr('cy', d => yScale(yValue2(d)))
        .attr('cx', d => xScale(xValue(d)))
        .attr('r', circleRadius)
        .attr('stroke', d => colorScale(d.IsGoodRating))
        .attr("fill", "None")
        /*
        .attr("stroke", function(d) {
          if (d.IsGoodRating == 1 ) {
                  return "blue"
            } else {
                  return "red"
            }
         })*/
        .attr("stroke-width",2);


    var colorLegendG = svg.append('g')
        .attr('transform', `translate(860,70)`);
    
    colorLegendG.call(colorLegend, {
      colorScale,
      circleRadius: 8,
      spacing: 20,
      textOffset: 12,
      backgroundRectWidth: 120
    });


    g.append('text')
        .attr('class', 'title')
        .attr('y', -10)
        .text(title2);




////////////////////


});

//   d3.csv('https://raw.githubusercontent.com/yqinolive/DataViz/master/movies.csv')
//     .then(data => {
//     	data.forEach(d => {
//       d.Rating = +d.Rating 
//       d.WinsNoms = +d.WinsNoms
//       d.year = +d.year
//       d.Budget =+ d.Budget;
//     });
//     render(data);
//   });

// }(d3));

///////# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbIi4uL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIHNlbGVjdCxcbiAgY3N2LFxuICBzY2FsZUxpbmVhcixcbiAgZXh0ZW50LFxuICBheGlzTGVmdCxcbiAgYXhpc0JvdHRvbSxcbiAgZm9ybWF0XG59IGZyb20gJ2QzJztcblxuY29uc3Qgc3ZnID0gc2VsZWN0KCdzdmcnKTtcblxuY29uc3Qgd2lkdGggPSArc3ZnLmF0dHIoJ3dpZHRoJyk7XG5jb25zdCBoZWlnaHQgPSArc3ZnLmF0dHIoJ2hlaWdodCcpO1xuXG5jb25zdCByZW5kZXIgPSBkYXRhID0+IHtcbiAgY29uc3QgeFZhbHVlID0gZCA9PiBkLndlaWdodDtcbiAgY29uc3QgeEF4aXNMYWJlbCA9ICdDYXIgd2VpZ2h0JztcbiAgXG4gIGNvbnN0IHlWYWx1ZSA9IGQgPT4gZC5ob3JzZXBvd2VyO1xuICBjb25zdCB5QXhpc0xhYmVsID0gJ0hvcnNlcG93ZXInO1xuICBjb25zdCBjaXJjbGVSYWRpdXMgPSAxMDtcbiAgXG4gIGNvbnN0IHRpdGxlID0gJ0NhcnMgRGF0YXNldCc7XG4gIGNvbnN0IG1hcmdpbiA9IHsgdG9wOiA1MCwgcmlnaHQ6IDQwLCBib3R0b206IDc3LCBsZWZ0OiAxMjAgfTtcbiAgY29uc3QgaW5uZXJXaWR0aCA9IHdpZHRoIC0gbWFyZ2luLmxlZnQgLSBtYXJnaW4ucmlnaHQ7XG4gIGNvbnN0IGlubmVySGVpZ2h0ID0gaGVpZ2h0IC0gbWFyZ2luLnRvcCAtIG1hcmdpbi5ib3R0b207XG4gIFxuICBjb25zdCB4U2NhbGUgPSBzY2FsZUxpbmVhcigpXG4gICAgLmRvbWFpbihleHRlbnQoZGF0YSwgeFZhbHVlKSlcbiAgICAucmFuZ2UoWzAsIGlubmVyV2lkdGhdKVxuICAgIC5uaWNlKCk7XG4gIFxuICBjb25zdCB5U2NhbGUgPSBzY2FsZUxpbmVhcigpXG4gICAgLmRvbWFpbihleHRlbnQoZGF0YSwgeVZhbHVlKSlcbiAgICAucmFuZ2UoW2lubmVySGVpZ2h0LCAwXSlcbiAgXHQubmljZSgpOztcbiAgXG4gIGNvbnN0IGcgPSBzdmcuYXBwZW5kKCdnJylcbiAgICAuYXR0cigndHJhbnNmb3JtJywgYHRyYW5zbGF0ZSgke21hcmdpbi5sZWZ0fSwke21hcmdpbi50b3B9KWApO1xuICBcbiAgY29uc3QgeEF4aXNUaWNrRm9ybWF0ID0gbnVtYmVyID0+XG4gICAgZm9ybWF0KCcuM3MnKShudW1iZXIpXG4gICAgICAucmVwbGFjZSgnRycsICdCJyk7XG4gIFxuICBjb25zdCB4QXhpcyA9IGF4aXNCb3R0b20oeFNjYWxlKVxuICAgIC50aWNrRm9ybWF0KHhBeGlzVGlja0Zvcm1hdClcbiAgICAudGlja1NpemUoLWlubmVySGVpZ2h0KVxuICBcdC50aWNrUGFkZGluZygyMCk7XG4gIFxuICBjb25zdCB5QXhpcyA9IGF4aXNMZWZ0KHlTY2FsZSlcbiAgICAudGlja1NpemUoLWlubmVyV2lkdGgpO1xuICBcbiAgY29uc3QgeUF4aXNHID0gZy5hcHBlbmQoJ2cnKS5jYWxsKHlBeGlzKTtcbiAgeUF4aXNHLnNlbGVjdEFsbCgnLmRvbWFpbicpLnJlbW92ZSgpO1xuICBcbiAgY29uc3QgeEF4aXNHID0gZy5hcHBlbmQoJ2cnKS5jYWxsKHhBeGlzKVxuICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBgdHJhbnNsYXRlKDAsJHtpbm5lckhlaWdodH0pYCk7XG4gIFxuICB5QXhpc0cuYXBwZW5kKCd0ZXh0JylcbiAgICAgIC5hdHRyKCdjbGFzcycsICdheGlzLWxhYmVsJylcbiAgICAgIC5hdHRyKCd5JywgLTcwKVxuICAgICAgLmF0dHIoJ3gnLCAtaW5uZXJIZWlnaHQvMilcbiAgXHRcdC5hdHRyKCd0cmFuc2Zvcm0nLCBgcm90YXRlKC05MClgKVxuICBcdFx0LmF0dHIoJ3RleHQtYW5jaG9yJywgJ21pZGRsZScpXG4gICAgICAuYXR0cignZmlsbCcsICdibGFjaycpXG4gICAgICAudGV4dCh5QXhpc0xhYmVsKTtcbiAgXG4gIHhBeGlzRy5zZWxlY3QoJy5kb21haW4nKS5yZW1vdmUoKTtcbiAgXG4gIHhBeGlzRy5hcHBlbmQoJ3RleHQnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgJ2F4aXMtbGFiZWwnKVxuICAgICAgLmF0dHIoJ3knLCA2NSlcbiAgICAgIC5hdHRyKCd4JywgaW5uZXJXaWR0aCAvIDIpXG4gICAgICAuYXR0cignZmlsbCcsICdibGFjaycpXG4gICAgICAudGV4dCh4QXhpc0xhYmVsKTtcblxuICBcbiAgZy5zZWxlY3RBbGwoJ2NpcmNsZScpLmRhdGEoZGF0YSlcbiAgICAuZW50ZXIoKS5hcHBlbmQoJ2NpcmNsZScpXG4gICAgICAuYXR0cignY3knLCBkID0+IHlTY2FsZSh5VmFsdWUoZCkpKVxuICAgICAgLmF0dHIoJ2N4JywgZCA9PiB4U2NhbGUoeFZhbHVlKGQpKSlcbiAgICAgIC5hdHRyKCdyJywgY2lyY2xlUmFkaXVzKTtcbiAgXG4gIGcuYXBwZW5kKCd0ZXh0JylcbiAgICAgIC5hdHRyKCdjbGFzcycsICd0aXRsZScpXG4gICAgICAuYXR0cigneScsIC0xMClcbiAgICAgIC50ZXh0KHRpdGxlKTtcbn07XG5cbmNzdignaHR0cHM6Ly92aXpodWIuY29tL2N1cnJhbi9kYXRhc2V0cy9hdXRvLW1wZy5jc3YnKVxuICAudGhlbihkYXRhID0+IHtcbiAgXHRkYXRhLmZvckVhY2goZCA9PiB7XG4gICAgZC5tcGcgPSArZC5tcGdcbiAgICBkLmN5bGluZGVycyA9ICtkLmN5bGluZGVycyAgXG4gICAgZC5kaXNwbGFjZW1lbnQgPSArZC5kaXNwbGFjZW1lbnRcbiAgICBkLmhvcnNlcG93ZXIgPSArZC5ob3JzZXBvd2VyXG4gICAgZC53ZWlnaHQgPSArZC53ZWlnaHRcbiAgICBkLmFjY2VsZXJhdGlvbiA9ICtkLmFjY2VsZXJhdGlvblxuICAgIGQueWVhciA9ICtkLnllYXI7XG4gICAgICA7XG4gIH0pO1xuICByZW5kZXIoZGF0YSk7XG59KTsiXSwibmFtZXMiOlsic2VsZWN0Iiwic2NhbGVMaW5lYXIiLCJleHRlbnQiLCJmb3JtYXQiLCJheGlzQm90dG9tIiwiYXhpc0xlZnQiLCJjc3YiXSwibWFwcGluZ3MiOiI7OztFQVVBLE1BQU0sR0FBRyxHQUFHQSxTQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7O0VBRTFCLE1BQU0sS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztFQUNqQyxNQUFNLE1BQU0sR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7O0VBRW5DLE1BQU0sTUFBTSxHQUFHLElBQUksSUFBSTtJQUNyQixNQUFNLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztJQUM3QixNQUFNLFVBQVUsR0FBRyxZQUFZLENBQUM7O0lBRWhDLE1BQU0sTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDO0lBQ2pDLE1BQU0sVUFBVSxHQUFHLFlBQVksQ0FBQztJQUNoQyxNQUFNLFlBQVksR0FBRyxFQUFFLENBQUM7O0lBRXhCLE1BQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQztJQUM3QixNQUFNLE1BQU0sR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztJQUM3RCxNQUFNLFVBQVUsR0FBRyxLQUFLLEdBQUcsTUFBTSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDO0lBQ3RELE1BQU0sV0FBVyxHQUFHLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUM7O0lBRXhELE1BQU0sTUFBTSxHQUFHQyxjQUFXLEVBQUU7T0FDekIsTUFBTSxDQUFDQyxTQUFNLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO09BQzVCLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztPQUN0QixJQUFJLEVBQUUsQ0FBQzs7SUFFVixNQUFNLE1BQU0sR0FBR0QsY0FBVyxFQUFFO09BQ3pCLE1BQU0sQ0FBQ0MsU0FBTSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztPQUM1QixLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7TUFDeEIsSUFBSSxFQUFFLENBQUM7SUFFVCxNQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztPQUN0QixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7SUFFaEUsTUFBTSxlQUFlLEdBQUcsTUFBTTtNQUM1QkMsU0FBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztTQUNsQixPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDOztJQUV2QixNQUFNLEtBQUssR0FBR0MsYUFBVSxDQUFDLE1BQU0sQ0FBQztPQUM3QixVQUFVLENBQUMsZUFBZSxDQUFDO09BQzNCLFFBQVEsQ0FBQyxDQUFDLFdBQVcsQ0FBQztNQUN2QixXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7O0lBRWxCLE1BQU0sS0FBSyxHQUFHQyxXQUFRLENBQUMsTUFBTSxDQUFDO09BQzNCLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDOztJQUV6QixNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QyxNQUFNLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDOztJQUVyQyxNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7T0FDckMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLFlBQVksRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7SUFFcEQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7U0FDaEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUM7U0FDM0IsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQztTQUNkLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO09BQzNCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQztPQUNoQyxJQUFJLENBQUMsYUFBYSxFQUFFLFFBQVEsQ0FBQztTQUMzQixJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQztTQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7O0lBRXRCLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7O0lBRWxDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1NBQ2hCLElBQUksQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDO1NBQzNCLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDO1NBQ2IsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFVLEdBQUcsQ0FBQyxDQUFDO1NBQ3pCLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDO1NBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzs7O0lBR3RCLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztPQUM3QixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO1NBQ3RCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNsQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDbEMsSUFBSSxDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsQ0FBQzs7SUFFN0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7U0FDWCxJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQztTQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDO1NBQ2QsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0dBQ2xCLENBQUM7O0FBRUZDLFFBQUcsQ0FBQyxpREFBaUQsQ0FBQztLQUNuRCxJQUFJLENBQUMsSUFBSSxJQUFJO0tBQ2IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUk7TUFDakIsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFHO01BQ2QsQ0FBQyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQyxVQUFTO01BQzFCLENBQUMsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDLENBQUMsYUFBWTtNQUNoQyxDQUFDLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVU7TUFDNUIsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFNO01BQ3BCLENBQUMsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDLENBQUMsYUFBWTtNQUNoQyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztLQUVsQixDQUFDLENBQUM7SUFDSCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7R0FDZCxDQUFDOzs7OyJ9